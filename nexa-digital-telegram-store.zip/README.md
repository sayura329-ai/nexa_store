# NEXA DIGITAL — website toko digital + bot Telegram

## Isi
- `index.html`: storefront dan dashboard owner.
- `netlify/functions/api.mjs`: API produk, pesanan, login owner, verifikasi pembayaran.
- `netlify/functions/telegram.mjs`: bot laporan owner.
- `supabase.sql`: struktur database.

## 1. Buat database Supabase
1. Buat project di https://supabase.com
2. Buka SQL Editor, tempel seluruh `supabase.sql`, lalu Run.
3. Dari Project Settings → API, salin Project URL dan `service_role` key. Service role adalah rahasia, jangan pernah dibagikan atau dimasukkan ke HTML.

## 2. Siapkan bot Telegram
1. Buka Telegram dan chat `@BotFather`.
2. Kirim `/newbot`, ikuti langkahnya, lalu simpan token bot secara rahasia.
3. Chat bot yang baru dibuat dan tekan Start.
4. Ambil chat ID owner dengan cara sementara membuka `https://api.telegram.org/bot<TOKEN>/getUpdates` setelah mengirim pesan ke bot. Cari `message.chat.id`. Jangan bagikan token atau URL yang mengandung token.
5. Buat secret acak panjang untuk `TELEGRAM_WEBHOOK_SECRET`.

## 3. Deploy ke Netlify
1. Upload folder ini ke GitHub, lalu di Netlify pilih Add new site → Import from Git.
2. Site settings → Environment variables, tambahkan:
   - `SUPABASE_URL` = URL project Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` = service_role key
   - `OWNER_PASSWORD` = password owner yang panjang dan unik
   - `TELEGRAM_BOT_TOKEN` = token dari BotFather
   - `TELEGRAM_OWNER_CHAT_ID` = chat ID owner
   - `TELEGRAM_WEBHOOK_SECRET` = secret acak
3. Deploy/redeploy setelah mengatur environment variables.

## 4. Aktifkan webhook Telegram
Setelah website live, jalankan sekali di browser atau terminal dengan mengganti nilai placeholder. Jangan kirim URL berisi token kepada siapa pun:

`https://api.telegram.org/bot<TOKEN_BOT>/setWebhook?url=https://NAMA-SITE.netlify.app/.netlify/functions/telegram&secret_token=SECRET_WEBHOOK`

Telegram mengharuskan secret token 1–256 karakter dari huruf/angka/underscore/dash. Untuk kemudahan, gunakan secret acak dengan karakter tersebut saja. Pastikan `TELEGRAM_WEBHOOK_SECRET` sama persis dengan nilai `SECRET_WEBHOOK`.

## 5. Tes
- Buka website, login owner, tambah produk dan stok.
- Buat pesanan dari halaman depan.
- Transfer diverifikasi manual oleh owner dari dashboard setelah bukti transfer diperiksa.
- Di chat bot owner coba `/omzet`, `/untung`, `/stok`, `/hariini`.

## Catatan penting sebelum dipakai pelanggan
- Ini starter project untuk prototipe. Pesanan yang belum dibayar tidak mengurangi stok; saat verifikasi, stok dikurangi. Jika stok sudah habis, verifikasi akan ditolak.
- Verifikasi transfer dilakukan manual; website tidak membuktikan pembayaran otomatis.
- Untuk akun game, jangan meminta password akun pembeli. Isi detail cukup ID game/server atau detail aman yang diperlukan.
- Login owner versi starter memakai bearer token berbasis `OWNER_PASSWORD` untuk memudahkan pemasangan. Untuk toko publik dengan nilai transaksi tinggi, ganti dengan autentikasi sesi yang proper, rate limiting, proteksi spam, dan audit keamanan.
- Perhitungan keuntungan = harga jual dikurangi modal yang dicatat saat pesanan dibuat; belum termasuk biaya admin, refund, dan biaya operasional.
- Lakukan uji transaksi kecil sebelum dipublikasikan. Jangan masukkan data rekening pribadi ke kode frontend; berikan instruksi pembayaran melalui saluran yang aman.
