const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
const env = () => ({
  url: process.env.SUPABASE_URL?.replace(/\/$/, ""),
  key: process.env.SUPABASE_SERVICE_ROLE_KEY,
  password: process.env.OWNER_PASSWORD,
  bot: process.env.TELEGRAM_BOT_TOKEN,
  chat: process.env.TELEGRAM_OWNER_CHAT_ID
});
async function db(path, method="GET", body) {
  const e=env(); if(!e.url||!e.key) throw Error("Backend belum dikonfigurasi: isi SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY.");
  const r=await fetch(`${e.url}/rest/v1/${path}`,{method,headers:{apikey:e.key,Authorization:`Bearer ${e.key}`,"Content-Type":"application/json",Prefer:method==="POST"?"return=representation":method==="PATCH"?"return=representation":""},...(body?{body:JSON.stringify(body)}:{})});
  const t=await r.text(); let data; try{data=t?JSON.parse(t):null}catch{data=t}
  if(!r.ok) throw Error(data?.message||data?.hint||"Database error"); return data;
}
async function telegram(text) {
 const e=env(); if(!e.bot||!e.chat)return;
 await fetch(`https://api.telegram.org/bot${e.bot}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:e.chat,text,parse_mode:"HTML"})});
}
function money(n){return "Rp"+Number(n||0).toLocaleString("id-ID")}
function auth(event){const e=env();return !!e.password && event.headers.authorization==="Bearer "+e.password}
async function getStats(){
 const all=await db("orders?select=total,cost_total,status");
 const completed=all.filter(x=>x.status==="paid");
 return {revenue:completed.reduce((s,x)=>s+Number(x.total),0),profit:completed.reduce((s,x)=>s+Number(x.total)-Number(x.cost_total),0),pending:all.filter(x=>x.status==="pending").length,completed:completed.length};
}
export async function handler(event){
 if(event.httpMethod==="OPTIONS")return {statusCode:204,headers};
 try{
  const e=env(), action=event.queryStringParameters?.action;
  const data=event.body?JSON.parse(event.body):{};
  if(action==="login"){
   if(!e.password||data.password!==e.password)return reply(401,{error:"Password owner salah atau OWNER_PASSWORD belum disetel."});
   return reply(200,{token:e.password});
  }
  if(action==="products"){
   const products=await db("products?select=id,name,description,price,stock,active&active=eq.true&order=created_at.desc");
   return reply(200,{products});
  }
  if(action==="createOrder"){
   const name=String(data.name||"").trim(),contact=String(data.contact||"").trim(),detail=String(data.detail||"").trim();
   if(!name||!contact||name.length>80||contact.length>100||detail.length>180)return reply(400,{error:"Isi nama dan kontak yang valid."});
   const found=await db(`products?select=id,name,price,cost,stock,active&id=eq.${encodeURIComponent(data.productId)}&active=eq.true`);
   const p=found?.[0]; if(!p)return reply(404,{error:"Produk tidak ditemukan."}); if(p.stock<1)return reply(409,{error:"Stok habis."});
   // Stock is reserved only at payment verification to avoid unpaid orders locking inventory.
   const code="NX"+Date.now().toString().slice(-8);
   const order=(await db("orders","POST",{code,product_id:p.id,product_name:p.name,buyer_name:name,buyer_contact:contact,buyer_detail:detail,total:p.price,cost_total:p.cost,status:"pending"}))[0];
   await telegram(`🛒 <b>Pesanan baru</b>\nKode: <code>${code}</code>\nProduk: ${p.name}\nTotal: ${money(p.price)}\nPembeli: ${name}\nKontak: ${contact}\nDetail: ${detail||"-"}\nStatus: menunggu transfer/verifikasi.`);
   return reply(200,{order:{id:order.id,code,total:order.total}});
  }
  if(!auth(event))return reply(401,{error:"Auth diperlukan. Login owner terlebih dahulu."});
  if(action==="dashboard"){
   const [products,orders,stats]=await Promise.all([
    db("products?select=*&order=created_at.desc"),
    db("orders?select=*&order=created_at.desc&limit=100"),
    getStats()
   ]);
   return reply(200,{products,orders,stats});
  }
  if(action==="saveProduct"){
   const name=String(data.name||"").trim(),price=Number(data.price),cost=Number(data.cost),stock=Number(data.stock),description=String(data.description||"").trim();
   if(!name||name.length>120||![price,cost,stock].every(Number.isFinite)||price<0||cost<0||stock<0||!Number.isInteger(stock))return reply(400,{error:"Nama, harga, modal, atau stok tidak valid."});
   const payload={name,description,price,cost,stock,active:true};
   const saved=data.id?await db(`products?id=eq.${encodeURIComponent(data.id)}`,"PATCH",payload):await db("products","POST",payload);
   return reply(200,{product:saved?.[0]});
  }
  if(action==="deleteProduct"){
   await db(`products?id=eq.${encodeURIComponent(data.id)}`,"PATCH",{active:false});return reply(200,{ok:true});
  }
  if(action==="verifyOrder"){
   const found=await db(`orders?select=*&id=eq.${encodeURIComponent(data.id)}`);
   const o=found?.[0];if(!o)return reply(404,{error:"Pesanan tidak ditemukan."});
   if(o.status!=="pending")return reply(409,{error:"Pesanan sudah diproses."});
   if(data.approve){
    const ps=await db(`products?select=id,stock,name&id=eq.${encodeURIComponent(o.product_id)}`);
    const p=ps?.[0];if(!p||p.stock<1)return reply(409,{error:"Stok habis. Tambah stok atau tolak pesanan."});
    await db(`products?id=eq.${encodeURIComponent(p.id)}`,"PATCH",{stock:p.stock-1});
    await db(`orders?id=eq.${encodeURIComponent(o.id)}`,"PATCH",{status:"paid",paid_at:new Date().toISOString()});
    await telegram(`✅ <b>Pembayaran diverifikasi</b>\nKode: <code>${o.code}</code>\nProduk: ${o.product_name}\nOmzet: ${money(o.total)}\nPerkiraan untung: ${money(Number(o.total)-Number(o.cost_total))}`);
   }else{
    await db(`orders?id=eq.${encodeURIComponent(o.id)}`,"PATCH",{status:"rejected"});
    await telegram(`❌ Pesanan ${o.code} ditolak.`);
   }
   return reply(200,{ok:true});
  }
  return reply(404,{error:"Action tidak dikenal."});
 }catch(err){return reply(500,{error:err.message||"Kesalahan server."})}
}