const reply=(statusCode,body)=>({statusCode,headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
async function db(path){
 const r=await fetch(`${process.env.SUPABASE_URL.replace(/\/$/,"")}/rest/v1/${path}`,{headers:{apikey:process.env.SUPABASE_SERVICE_ROLE_KEY,Authorization:`Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`}});
 const t=await r.text();if(!r.ok)throw Error("DB error");return t?JSON.parse(t):[];
}
async function send(chat_id,text){
 return fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id,text,parse_mode:"HTML"})});
}
const money=n=>"Rp"+Number(n||0).toLocaleString("id-ID");
export async function handler(event){
 try{
  if(event.httpMethod!=="POST")return reply(200,{ok:true});
  const secret=process.env.TELEGRAM_WEBHOOK_SECRET;
  if(secret&&event.headers["x-telegram-bot-api-secret-token"]!==secret)return reply(401,{error:"unauthorized"});
  const update=JSON.parse(event.body||"{}"),msg=update.message;
  if(!msg?.text)return reply(200,{ok:true});
  const owner=String(process.env.TELEGRAM_OWNER_CHAT_ID||"");
  if(!owner||String(msg.chat.id)!==owner)return reply(200,{ok:true});
  const cmd=msg.text.trim().split(/\s+/)[0].split("@")[0].toLowerCase();
  if(!["/start","/help","/omzet","/untung","/stok","/hariini"].includes(cmd))return reply(200,{ok:true});
  let text="";
  if(cmd==="/start"||cmd==="/help")text="NEXA DIGITAL OWNER BOT\n/omzet — total omzet terverifikasi\n/untung — perkiraan keuntungan\n/stok — stok produk\n/hariini — laporan transaksi hari ini";
  if(cmd==="/omzet"||cmd==="/untung"){
   const orders=await db("orders?select=total,cost_total,status&status=eq.paid");
   const rev=orders.reduce((s,o)=>s+Number(o.total),0),profit=orders.reduce((s,o)=>s+Number(o.total)-Number(o.cost_total),0);
   text=cmd==="/omzet"?`📈 Total omzet terverifikasi: ${money(rev)}`:`💰 Perkiraan keuntungan: ${money(profit)}\nTransaksi berhasil: ${orders.length}`;
  }
  if(cmd==="/stok"){
   const ps=await db("products?select=name,stock,active&active=eq.true&order=name.asc");
   text="📦 <b>STOK PRODUK</b>\n"+(ps.length?ps.map(p=>`${p.name}: ${p.stock}`).join("\n"):"Belum ada produk");
  }
  if(cmd==="/hariini"){
   const since=new Date();since.setHours(0,0,0,0);
   const os=await db(`orders?select=total,cost_total,status,paid_at&status=eq.paid&paid_at=gte.${encodeURIComponent(since.toISOString())}`);
   const rev=os.reduce((s,o)=>s+Number(o.total),0),profit=os.reduce((s,o)=>s+Number(o.total)-Number(o.cost_total),0);
   text=`📊 <b>LAPORAN HARI INI</b>\nTransaksi berhasil: ${os.length}\nOmzet: ${money(rev)}\nPerkiraan untung: ${money(profit)}`;
  }
  await send(msg.chat.id,text);
  return reply(200,{ok:true});
 }catch(e){return reply(200,{ok:false})}
}