create extension if not exists pgcrypto;

create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 description text default '',
 price numeric(14,2) not null default 0 check(price >= 0),
 cost numeric(14,2) not null default 0 check(cost >= 0),
 stock integer not null default 0 check(stock >= 0),
 active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 product_id uuid references public.products(id),
 product_name text not null,
 buyer_name text not null,
 buyer_contact text not null,
 buyer_detail text default '',
 total numeric(14,2) not null default 0,
 cost_total numeric(14,2) not null default 0,
 status text not null default 'pending' check(status in ('pending','paid','rejected')),
 created_at timestamptz not null default now(),
 paid_at timestamptz
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
-- Semua akses dilakukan melalui Netlify Functions dengan service-role key yang hanya disimpan di server.
-- Jangan pernah menaruh SUPABASE_SERVICE_ROLE_KEY di index.html.
